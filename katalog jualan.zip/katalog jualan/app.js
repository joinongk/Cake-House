const nomorDana = "082241149645";
const nomorWhatsapp = "6282241149645";

fetch("products.json")
  .then(res => res.json())
  .then(data => {
    const list = document.getElementById("product-list");

    data.forEach(item => {
      const pesanWA = encodeURIComponent(
        `Halo, saya mau beli ${item.name} dengan harga Rp ${item.price.toLocaleString("id-ID")}.
Pembayaran via DANA ke nomor ${nomorDana}.`
      );

      list.innerHTML += `
        <div class="product">
          <img src="${item.image}" alt="${item.name}">
          <h2>${item.name}</h2>
          <p>${item.description}</p>
          <div class="price">Rp ${item.price.toLocaleString("id-ID")}</div>

          <a 
            class="btn-dana" 
            href="https://wa.me/${nomorWhatsapp}?text=${pesanWA}" 
            target="_blank">
            Bayar via DANA
          </a>
        </div>
      `;
    });
  });
